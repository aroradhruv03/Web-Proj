<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<h1><?php echo "Auto"?></h1>


<?php
	
	$connection = mysql_connect("localhost","root","root");
			// Selecting Database
	$db = mysql_select_db("User", $connection);
	echo "connected";
	$query = mysql_query("select item_name, from items where category_id=1",$connection );
		
		//$ads = array();
		while($ad=mysql_fetch_assoc($query)) 
		{	//$ads[]=$ad['item_id'];

       		echo "<br/>".$ad['item_name'];
       	}

?>


</body>
</html>