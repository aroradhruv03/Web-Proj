<?php
/**
 * Created by
 * User: dhruv
 * Date: 11/25/15
 * Time: 3:35 AM
 */

$DB_host = "localhost";
$DB_user = "root";
$DB_pass = "root";
$DB_name = "User";

?>