<?php
include('login_script.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
    header("Location: index.php");

}
?>
<!-- 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/styles.css" />
</head>
<body>

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h2 class="text-center"><img src="" class="img-circle"><br>Login</h2>
            </div>
            <div class="modal-body row">
                <h6 class="text-center">COMPLETE THESE FIELDS TO SIGN IN</h6>
                <! DHRUV ADDING STUFF START -
                <div id="login">
                    <form class="col-md-10 col-md-offset-1 col-xs-12 col-xs-offset-0" action="" method="post">
                        <div class="form-group">
                            <input type="email" class="form-control input-lg" placeholder="Enter your Email" id="user_email" name="user_email" required>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control input-lg" placeholder="Enter your Password" id="user_password" name="user_password" required>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-lg btn-block" type="submit" name="submit">Sign In</button>
                            <span class="pull-right"><a href="#">Register</a></span><span><a href="#">Need help?</a></span>
                        </div>
                        <span><?php  $error; ?></span></div>
                    </form>
                </div>
                 DHRUV ADDING STUFF END -
                <div class="modal-footer">
                    <h6 class="text-center"><a href="">Privacy is important to us. Click here to read why.</a></h6>
                </div>
            </div>
        </div>

        <!scripts loaded here-

        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <script src="js/scripts.js"></script>
    </body>
    </html>
    -->

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <div id="login">
                    <form action="" method="post">
                        <div class="form-group">
                            <input type="email" placeholder="Enter your Email" id="user_email" name="user_email" required>
                        </div>
                        <div >
                            <input type="password" placeholder="Enter your Password" id="user_password" name="user_password" required>
                        </div>
                        <div >
                            <button type="submit" name="submit">Sign In</button> 
                        </div>
                        <span><?php echo $error; ?></span></div>
                    </form>
                </div>
</body>
</html>