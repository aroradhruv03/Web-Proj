<?php

include('image_upload.php');

$item_name = $price = $description = $image_url = "";

echo $_POST['item_name'];
echo "<br/>";
echo $_POST['price'];
echo "<br/>"; 

echo $_POST['desc'];
echo "<br/>";

echo $_POST['category'];
echo "<br/>";

echo $target_path;

?>