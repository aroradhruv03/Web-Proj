<?php 
//This File will contain the login processing details

session_start(); // Starting Session
$error_msg=''; // Variable to store error message

if(isset($_POST['submit']))
{
	if(empty($_POST['user_email']) || empty($_POST['user_password']))
	{
		$error_msg = 'Username or Password is invalid';
	}
	else
	{
		// 
		$user_email = $_POST['user_email'];
		$user_password = $_POST['user_password'];

		// Establishing Connection with Server by passing server_name, user_id and password as a parameter
		$connection = mysql_connect("localhost","root","root");

		//
		$user_email = stripslashes($user_email);
		$user_password = stripslashes($user_password);

		$user_email = mysql_real_escape_string($user_email);
		$user_password = mysql_real_escape_string($user_password);

		// Selecting Database
		$db = mysql_select_db("User", $connection);
		// SQL query to fetch information of registerd users and finds user match.
		$query = mysql_query("select * from user where Password='$user_password' AND email='$user_email'", $connection);
		$rows = mysql_num_rows($query);
		if ($rows == 1) 
		{
		$_SESSION['login_user']=$user_email; // Initializing Session
		header("location: profile.php"); // Redirecting To Other Page
		} 
		else {
			$error = "Username or Password is invalid";
		}
		mysql_close($connection); // Closing Connection
	}
}
?>